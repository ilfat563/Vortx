#!/bin/bash
set -e
npm install
rm -rf www && mkdir www && cp -r web/* www/
npx cap add android
npx cap sync android
(cd android && chmod +x gradlew && ./gradlew assembleRelease --no-daemon)
APK=android/app/build/outputs/apk/release/app-release-unsigned.apk
BT=$(ls -d "$ANDROID_HOME"/build-tools/* | sort -V | tail -1)
"$BT/zipalign" -p -f 4 "$APK" aligned.apk
"$BT/apksigner" sign --ks vortx.jks --ks-pass pass:vortx2026 --key-pass pass:vortx2026 --out vortx.apk aligned.apk
ls -la vortx.apk
